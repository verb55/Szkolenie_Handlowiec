# Specyfikacja Funkcjonalna — Sales Assistant WebApp

## Kontekst Produktu

**Użytkownik:** Handlowiec B2B w terenie, słuchawki w uszach, telefon w ręku

**Platforma:** WebApp (PWA), ekran 6", obsługa jednym kciukiem

**Metoda bazowa:** Hak → Akceptacja → Diagnoza → Rozwiązanie → Autorytet → Zamknięcie (metodologia Karola Fronia)

**Ograniczenia:** Brak budżetu na AI real-time, musi działać offline

---

## Tryby Myślenia

- **[PSYCHOLOG]** → motywacja, odporność, grywalizacja
- **[UX]** → interfejs mobilny, gesty, single-thumb navigation
- **[SPRZEDAŻ]** → skuteczność skryptu, obsługa obiekcji, konwersja

---

## MODUŁ 1: Nawigacja Skryptem Jednym Kciukiem

**[UX MODE AKTYWNY]**

### (a) Co robi

System stref dotykowych pozwalający handlowcowi nawigować przez etapy skryptu bez patrzenia w ekran, używając gestów kciukiem. Automatycznie wykrywa "zgubienie" w rozmowie i oferuje szybki powrót do bieżącego kontekstu.

### (b) Jak wygląda — Ekran "Tryb Rozmowy"

Ekran podzielony na **5 stref dotykowych** (odpowiadających etapom HADAS):

| Strefa | Pozycja | Gesture | Funkcja |
|--------|---------|---------|---------|
| Lewa | 30% szerokości, lewa krawędź | Swipe RIGHT | "Wstecz" (poprzedni etap) |
| Prawa | 30% szerokości, prawa krawędź | Swipe LEFT | "Dalej" (następny etap) |
| Centrum | Pozostała przestrzeń | TAP | Podpowiedź obecnego etapu (2s) |
| Górny pasek | 15mm od góry | Pull DOWN | "ZGUBIŁEM SIĘ" (mapa skryptu) |
| Dolny pasek | 15mm od dołu | Pull UP | "SKIPUJ ETAP" (tylko gdy dostępny) |

**Wizualizacja postępu:** Pasek gradientowy na górze ekranu (szary → zielony) z ikoną obecnego etapu HADAS.

**Stan "ZGUBIŁEM SIĘ":** Po aktywacji górnej strefy wyświetla się mini-mapa skryptu z zaznaczonym aktualnym etapem. Handlowiec może tapnąć dowolny etap by wrócić.

### (c) Dlaczego to działa — Mechanizm UX

**Muscle memory + Peripheral vision:** Handlowiec buduje nawyk kinestetyczny (swipe w prawo = "dalej") identyczny do gestu "odpowiedz na połączenie". Kciuk naturalnie opiera się na prawej krawędzi przy trzymaniu telefonu — ta strefa jest najszybciej dostępna.

**"Zgubiłem się" recovery:** Strefa pull-down na górze wykorzystuje naturalny gest "scroll up" który użytkownik wykonuje instynktownie gdy szuka informacji. System nie pyta "co robisz?" tylko pokazuje mapę — handlowiec sam decyduje gdzie wrócić.

### (d) Ryzyko implementacyjne

**Pułapka:** Handlowiec mimowolnie aktywuje gesty podczas normalnego trzymania telefonu (np. readjust grip). Konieczne: **debounce 800ms** przed rejestracją gestu + wymóg ruchu >15mm + detekcja trajectory (nie случайный touch).

---

## MODUŁ 2: Rejection Recovery System

**[PSYCHOLOG MODE AKTYWNY]**

### (a) Co robi

Mechanizm grywalizacji normalizujący odrzucenie jako statystycznie oczekiwany element procesu sprzedaży, nagradzający za **podjęcie próby** (nie za wynik) i budujący odporność przez ekspozycję na narrację sukcesu.

### (b) Jak wygląda — Ekran "Streak Mode" (PO 5 ODRZUCENIACH)

Zamiast confetti — **ciemny ekran z jednym komunikatem:**

```
╔═══════════════════════════════════════╗
║                                       ║
║   STREAK: 5 połączeń                 ║
║   ▓▓▓▓▓░░░░  62% do celu             ║
║                                       ║
║   ● 3 handlowców z teamu              ║
║     właśnie też usłyszało "nie"       ║
║                                       ║
║   ⟳ Następne połączenie              ║
║                                       ║
╚═══════════════════════════════════════╝
```

**3 sekundy** — nie dłużej. Potem automatyczny powrót do ekranu wybierania kontaktu.

### (c) Dlaczego to działa — Mechanizm psychologiczny

**Social proof + normalizacja:** "3 handlowców z teamu też usłyszało nie" eliminuje izolację ("jestem jedynym nieudacznikiem").

**Re-framing through streaks:** Streak mierzy **próby**, nie sukcesy. Każde kolejne połączenie buduje streak niezależnie od wyniku. To wykorzystuje **progress principle** (Amabile) — poczucie postępu jest silniejszym motywatorem niż nagroda.

**Micro-dopamine hit:** Komunikat "62% do celu" (arbitralny progress bar) daje iluzoryczny postęp bez fałszywych obietnic. Nie ma nagrody — jest poczucie motion.

### (d) Ryzyko implementacyjne

**Pułapka:** Gamifikacja staje się irytująca gdy jest zbyt częsta ("You did it!" po każdym kliknięciu). Reguła: **maksimum 1 komunikat na 20 połączeń**, wyświetlany TYLKO po 5+ kolejnych odrzuceniach. Jeśli handlowiec ma streak 15 i dostaje "nie" — system milczy.

---

## MODUŁ 3: Drzewo Obiekcji Oparte na Słowach Kluczowych

**[SPRZEDAŻ MODE AKTYWNY]**

### (a) Co robi

System tagowania obiekcji w czasie rzeczywistym: handlowiec zaznacza 1-3 słowa klucze usłyszane od klienta, a system natychmiast wyświetla kontrargument, pytanie pogłębiające i sugerowaną ścieżkę powrotu do skryptu.

### (b) Jak wygląda — Ekran "Obsługa Obiekcji"

Po usłyszeniu obiekcji klienta:

```
╔══════════════════════════════════════════╗
║ OBIEKCJA KLIENTA                        ║
║ Zaznacz 1-3 słów kluczy:                ║
║                                          ║
║ [DROGO] [NIE TERAZ] [KONKURENCJA]       ║
║ [INNY DOSTAWCA] [NIEPOTRZEBNE]          ║
║ [ZA MAŁO] [SŁYSZAŁEM]                   ║
║                                          ║
║ ───────────────────────────────────────  ║
║ KONTRARGUMENT:                           ║
║ "Rozumiem że cena jest istotna.          ║
║ Czy mogę zapytać — przy podobnej          ║
║ cenie, co zaważyłoby na wyborze           ║
║ dostawcy?"                               ║
║                                          ║
║ → POWRÓT DO: [DIAGNOZA]                 ║
╚══════════════════════════════════════════╝
```

### (c) Dlaczego to działa — Mechanizm sprzedażowy

**Cognitive load reduction:** Handlowiec nie musi pamiętać 50+ gotowych odpowiedzi — rozpoznaje tylko emocję/sytuację klienta przez tag. System dostarcza gotowy kontrargument.

**Micro-conversation flow:** Powrót do DIAGNOZA (nie "Zamknięcie") jest kluczowy — nie próbuj zamknąć po obiekcji, tylko pogłębiaj zrozumienie. To zgodne z metodologią HADAS gdzie obiekcja = sygnał "nie mam wystarczających danych by powiedzieć TAK".

### (d) Struktura JSON obiekcji

```json
{
  "obiekcja_id": "cena_kwota",
  "tagi": ["drogo", "droższy", "kwota", "kosztuje", "nie stać"],
  "kontrargument": {
    "tekst": "Rozumiem że budżet jest istotny. Powiedz mi — gdybyśmy znaleźli rozwiązanie w tej samej cenie, ale z mniejszym ryzykiem wdrożenia, czy to zmieniłoby perspektywę?",
    "ton": "empatyczny",
    "czas_czytania_sek": 8
  },
  "pytanie_poglebiajace": "Co w tej chwili jest ważniejsze — cena wyjściowa czy całkowity koszt posiadania?",
  "powrot_do_etapu": "DIAGNOZA",
  "power_move": "Przenieś fokus z ceny jednostkowej na koszt problemu",
  "unikanie_fraz": ["oczywiście rozumiem", "pan/pani się myli"]
}
```

### (e) Ryzyko implementacyjne

**Pułapka:** Handlowiec taguje obiekcję BEZ SŁUCHANIA reszty wypowiedzi klienta, żeby "szybko przejść" do kontrargumentu. Rozwiązanie: system wymusza 3-sekundowy timer przed wyświetleniem kontrargumentu (handlowiec nie widzi go wcześniej, musi poczekać).

---

## MODUŁ 4: Just-in-Time Micro-Learning

**[PSYCHOLOG + UX MODE AKTYWNE]**

### (a) Co robi

Adaptacyjny system podpowiedzi (hints) który wyświetla się w momentach krytycznych rozmowy, samoczynnie znika po 4 sekundach, i uczy się które hints handlowiec ignoruje by przestać je pokazywać.

### (b) Jak wygląda — Ekran "Hints Panel"

**Nowicjusz (< 30 dni):**

```
┌─────────────────────────────────┐
│ 💡 "Pamiętaj — pozwól klientowi │
│    mówić. Cel: 70% klient,      │
│    30% ty."          ⏱ 4s      │
└─────────────────────────────────┘
```

(pojawia się w momencie gdy handlowiec mówi >50% czasu)

**Weteran (> 90 dni):**

```
┌─────────────────────────────────┐
│ 💡 "Ostatnia podpowiedź:        │
│    Sprawdź czy klient ma        │
│    budżet na Q2."    ⏱ 4s      │
└─────────────────────────────────┘
```

(tylko 1 hint na 10 rozmów, tylko strategiczny)

### (c) Dlaczego to działa — Mechanizm psychologiczny

**Just-in-time vs ahead-of-time:** Badania pokazują że learning jest skuteczniejszy gdy informacja pojawia się w MOMENCIE potrzeby, nie "przed" (kiedy kontekst jest abstrakcyjny).

**4-sekundowy timeout:** Eliminuje "mam wszystko podane na tacy" — handlowiec MUSI zapamiętać w 4 sekundy lub stracić hint. To mechanizm **spaced repetition w microskali**.

**Adaptacyjne wygaszanie:** Jeśli handlowiec nigdy nie reaguje na hint "pozwól klientowi mówić" (tj. hint znika, handlowiec nadal mówi), system przestaje go pokazywać. Zamiast tego pokazuje hint "zwolnij tempo" — alternatywny framing tego samego problemu.

### (d) Ryzyko implementacyjne

**Pułapka:** Hints pojawiają się w najgorszym momencie — np. w połowie wypowiedzi klienta. Konieczne: **kontekst detekcji** (czy klient mówi? czy handlowiec mówi? czy jest cisza?) — hint pokazuje się TYLKO podczas ciszy lub na początku rozmowy, nigdy gdy klient mówi.

---

## USER FLOW: Obsługa obiekcji "cena" + umówienie demo

| Krok | Akcja Handlowca | Reakcja Systemu | Następny |
|------|-----------------|------------------|----------|
| 1 | Odbiera połączenie (tap na centrum) | Wyświetla ekran rozmowy + pasek HADAS (#1:Hak) | → 2 |
| 2 | Mówi wstęp (raport) | Hints: "Pozwól mówić" (znika po 4s) | → 3 |
| 3 | Klient: "To jest za drogo" | Strefa prawa PULSUJE "Dotknij by otworzyć obsługę obiekcji" | → 4 |
| 4 | Gesture: swipe LEFT (strefa prawa) | Otwiera ekran OBIEKCJE + timer 3s "słuchaj..." | → 5 |
| 5 | Taguje: [DROGO] (tap na tag) | Wyświetla kontrargument + pytanie pogłębiające | → 6 |
| 6 | Mówi kontrargument "Czy przy podobnej cenie z mniejszym ryzykiem..." | Hints: "Powtórz kwotę klienta — to buduje zaufanie" | → 7 |
| 7 | Klient odpowiada (negocjuje) | System wykrywa ciszę po odpowiedzi klienta | → 8 |
| 8 | Gesture: swipe LEFT (kolejny etap) | Postęp HADAS: #4/Rozw. + CTA: "Umów demo?" | → 9 |
| 9 | Klient akceptuje "Tak, umówmy demo" | Modal: "Zapisz termin" + kalendarz inline | → 10 |
| 10 | Zapisuje termin (tap: data + godzina) | ✅ Sukces: "Demo: 15:00 Śr 22.04" + streak +1 | → 11 |
| 11 | Kończy rozmowę (gest: swipe RIGHT x2) | Ekran startowy + nowy kontakt | → 1 |

---

## Podsumowanie Architektoniczne

| Moduł | Primary Mode | Kluczowy UX Pattern | Główny Stress Test |
|-------|--------------|---------------------|-------------------|
| Nawigacja | UX | Gesture-based, zero-cognitive-load | False positive gestures |
| Rejection Recovery | Psycholog | Social proof, progress framing | Over-gamification |
| Drzewo Obiekcji | Sprzedaż | Tag → Instant response | Tagowanie bez słuchania |
| Micro-Learning | Psycholog+UX | Just-in-time, self-limiting | Timing vs. conversation context |

---

## Materiały

**GitHub:** https://github.com/verb55/Szkolenie_Handlowiec.git