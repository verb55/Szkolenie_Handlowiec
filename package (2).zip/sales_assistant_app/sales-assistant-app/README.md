# Sales Assistant WebApp

Aplikacja wspierająca handlowców B2B w terenie podczas cold callingu. Integruje perspektywy psychologiczne, UX oraz strategie sprzedażowe oparte na metodologii HADAS (Karol Fronia).

## Funkcjonalności

### Moduł 1: Nawigacja Skryptem Jednym Kciukiem
- System stref dotykowych pozwalający nawigować przez etapy skryptu bez patrzenia w ekran
- Gesty: swipe prawo/lewo do nawigacji, strefa górna dla mapy skryptu
- Automatyczne wykrywanie "zgubienia" i szybki powrót do bieżącego kontekstu

### Moduł 2: Rejection Recovery System
- Mechanizm grywalizacji normalizujący odrzucenie jako statystycznie oczekiwany element
- Nagradzanie za podjęcie próby (nie za wynik)
- Social proof i progress framing po 5+ kolejnych odrzuceniach

### Moduł 3: Drzewo Obiekcji
- Tagowanie obiekcji w czasie rzeczywistym na podstawie słów kluczowych
- Natychmiastowe wyświetlanie kontrargumentów i pytań pogłębiających
- Sugerowana ścieżka powrotu do skryptu

### Moduł 4: Just-In-Time Micro-Learning
- Adaptacyjny system podpowiedzi wyświetlanych w momentach krytycznych
- Samoczynne znikanie po 4 sekundach
- System uczenia się, które hinty użytkownik ignoruje

## Stack Technologiczny

- **Framework:** React 18
- **Build:** Vite
- **Język:** TypeScript
- **Stylizacja:** TailwindCSS
- **Stan:** Zustand + LocalForage (offline storage)
- **Animacje:** Framer Motion
- **UI Components:** Radix UI
- **Package Manager:** pnpm

## Instalacja

```bash
# Zainstaluj zależności
pnpm install

# Uruchom development server
pnpm dev

# Build produkcyjny
pnpm build

# Podgląd buildu lokalnie
pnpm preview
```

## Struktura Projektu

```
sales-assistant-app/
├── src/
│   ├── components/          # Komponenty React
│   │   ├── CallScreen.tsx
│   │   ├── ErrorBoundary.tsx
│   │   ├── HintsPanel.tsx
│   │   ├── ObjectionPanel.tsx
│   │   ├── RejectionRecovery.tsx
│   │   ├── StageNavigator.tsx
│   │   └── StartScreen.tsx
│   ├── data/               # Dane statyczne
│   │   ├── hints.json
│   │   ├── obiekcje.json
│   │   └── stages.ts
│   ├── hooks/              # Custom hooks
│   ├── store/              # Zustand stores
│   │   ├── useAppStore.ts
│   │   └── useHintsStore.ts
│   ├── lib/                # Utilsy
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── public/
├── dist/                   # Build output
├── tailwind.config.js
├── vite.config.ts
└── package.json
```

## Etykiety HADAS

| ID | Nazwa | Skrót | Opis |
|----|-------|-------|------|
| 1 | Hak | HK | Przyciągnięcie uwagi |
| 2 | Akceptacja | AK | Budowanie relacji |
| 3 | Diagnoza | DI | Zrozumienie potrzeb |
| 4 | Rozwiązanie | RO | Prezentacja oferty |
| 5 | Autorytet | AU | Wzmocnienie wiarygodności |
| 6 | Zamknięcie | ZM | Finalizacja sprzedaży |

## Gesty Nawigacji

| Strefa | Gest | Funkcja |
|--------|------|---------|
| Centrum | Tap | Podpowiedź etapu |
| Strefa prawa | Swipe Left | Następny etap |
| Strefa lewa | Swipe Right | Poprzedni etap |
| Strefa górna | Long Press | Mapa skryptu |
| Strefa górna | Pull Down | Tryb "Zgubiłem się" |

## Zmienne Środowiskowe

Aplikacja nie wymaga zmiennych środowiskowych do działania w trybie offline.

Dla przyszłej integracji z backendem:
```env
VITE_API_URL=https://api.example.com
VITE_API_KEY=your_api_key
```

## Wdrożenie

```bash
# Build
pnpm build

# Pliki wyjściowe są w dist/
# Można wdrożyć na dowolnym serwerze static hosting
```

## Ograniczenia MVP

- **Brak backendu:** Dane przechowywane lokalnie w IndexedDB
- **Brak uwierzytelniania:** Pełny dostęp dla wszystkich użytkowników
- **Brak synchronizacji:** Dane nie są synchronizowane między urządzeniami
- **Brak testów E2E:** Testy jednostkowe/integracyjne do wdrożenia

## Roadmap

1. Backend z bazą danych i API
2. System uwierzytelniania
3. Synchronizacja danych między urządzeniami
4. Testy automatyczne
5. Internacjonalizacja (i18n)

## Licencja

MIT
