import { useAppStore } from './store/useAppStore';
import { StartScreen } from './components/StartScreen';
import { CallScreen } from './components/CallScreen';

function App() {
  const { isCallActive } = useAppStore();

  return (
    <div className="font-sans antialiased">
      {/* Start/Home Screen */}
      {!isCallActive && <StartScreen />}

      {/* Active Call Screen */}
      {isCallActive && <CallScreen />}
    </div>
  );
}

export default App;
