import { useAppStore } from '../store/useAppStore';
import { StageNavigator } from './StageNavigator';
import { ObjectionPanel } from './ObjectionPanel';
import { HintsPanel } from './HintsPanel';
import { RejectionRecovery } from './RejectionRecovery';
import { Phone } from 'lucide-react';
import { motion } from 'framer-motion';

export function CallScreen() {
  const { isCallActive, resetSession, currentStageId, isLostMode, setLostMode } = useAppStore();

  if (!isCallActive) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-neutral-950">
      {/* Stage Navigator - handles all touch gestures */}
      <StageNavigator />

      {/* Objection Panel FAB */}
      <ObjectionPanel />

      {/* Adaptive Hints Panel */}
      <HintsPanel />

      {/* Rejection Recovery System */}
      <RejectionRecovery />

      {/* End Call Button */}
      <motion.button
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        onClick={() => resetSession()}
        className="fixed top-4 right-4 z-40 w-12 h-12 bg-red-600 hover:bg-red-500 rounded-full flex items-center justify-center shadow-lg"
        style={{ touchAction: 'manipulation' }}
      >
        <Phone className="w-5 h-5 text-white rotate-[135deg]" />
      </motion.button>
    </div>
  );
}
