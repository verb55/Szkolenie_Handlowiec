import React from 'react';

const sanitizeError = (error: any): string => {
  if (error instanceof Error) {
    // In production, log to external service instead of showing stack trace
    console.error('[Sales Assistant] Application error:', error.message);
    return 'Wystąpił nieoczekiwany błąd. Spróbuj odświeżyć stronę.';
  }
  console.error('[Sales Assistant] Unknown error:', error);
  return 'Wystąpił nieoczekiwany błąd. Spróbuj odświeżyć stronę.';
};

interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    // Log error details for debugging (would send to Sentry/Bugsnag in production)
    console.error('[Sales Assistant] Error caught by boundary:', {
      message: error.message,
      componentStack: errorInfo.componentStack,
    });
  }

  render(): React.ReactNode {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }
      return (
        <div className="p-6 bg-neutral-900 border border-red-900 rounded-xl">
          <h2 className="text-red-400 text-lg font-medium mb-2">Coś poszło nie tak</h2>
          <p className="text-neutral-400 text-sm">{sanitizeError(this.state.error)}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-sm"
          >
            Odśwież stronę
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
