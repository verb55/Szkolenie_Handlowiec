import { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useHintsStore, resetSessionIgnores } from '../store/useHintsStore';
import { useAppStore, getUserExperienceDays } from '../store/useAppStore';
import hintsData from '../data/hints.json';
import { Lightbulb } from 'lucide-react';

const HINT_DISPLAY_DURATION = 4000; // 4 seconds
const CHECK_INTERVAL = 5000; // Check for new hints every 5 seconds

export function HintsPanel() {
  const { hintVisible, currentHintId, hideHint, recordInteraction, getHintForStage } = useHintsStore();
  const { isCallActive, currentStageId, hintsDisabled } = useAppStore();
  const userDays = getUserExperienceDays();
  const hintTimerRef = useRef<NodeJS.Timeout | null>(null);
  const checkTimerRef = useRef<NodeJS.Timeout | null>(null);
  const wasVisibleRef = useRef(false);

  const currentHint = currentHintId
    ? hintsData.hints.find((h) => h.id === currentHintId)
    : null;

  // Reset session ignores on mount
  useEffect(() => {
    resetSessionIgnores();
  }, []);

  // Auto-hide hint after duration
  useEffect(() => {
    if (hintVisible && currentHintId) {
      hintTimerRef.current = setTimeout(() => {
        hideHint();
      }, HINT_DISPLAY_DURATION);

      return () => {
        if (hintTimerRef.current) {
          clearTimeout(hintTimerRef.current);
        }
      };
    }
  }, [hintVisible, currentHintId, hideHint]);

  // Check for new hints periodically during call
  useEffect(() => {
    if (!isCallActive || hintsDisabled) return;

    checkTimerRef.current = setInterval(() => {
      const stageMap: Record<number, string> = {
        1: 'Hak',
        2: 'Akceptacja',
        3: 'Diagnoza',
        4: 'Rozwiązanie',
        5: 'Autorytet',
        6: 'Zamknięcie',
      };

      const stageName = stageMap[currentStageId];
      if (stageName) {
        const hint = getHintForStage(stageName, userDays);
        if (hint) {
          // Random chance to show hint (1 in 3 to not be too intrusive)
          if (Math.random() < 0.33) {
            useHintsStore.getState().showHint(hint.id);
          }
        }
      }
    }, CHECK_INTERVAL);

    return () => {
      if (checkTimerRef.current) {
        clearInterval(checkTimerRef.current);
      }
    };
  }, [isCallActive, currentStageId, hintsDisabled, userDays, getHintForStage]);

  // Track if hint was visible for interaction detection
  useEffect(() => {
    if (hintVisible && !wasVisibleRef.current) {
      wasVisibleRef.current = true;
    } else if (!hintVisible && wasVisibleRef.current) {
      // Hint just disappeared, record as ignored if not interacted
      if (currentHintId) {
        recordInteraction(currentHintId, false);
      }
      wasVisibleRef.current = false;
    }
  }, [hintVisible, currentHintId, recordInteraction]);

  const handleHintTap = () => {
    if (currentHintId) {
      recordInteraction(currentHintId, true);
    }
    hideHint();
  };

  if (!isCallActive || hintsDisabled) {
    return null;
  }

  return (
    <AnimatePresence>
      {hintVisible && currentHint && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ duration: 0.2 }}
          className="fixed bottom-24 left-4 right-4 z-30"
          onClick={handleHintTap}
        >
          <div className="bg-blue-900/90 backdrop-blur-sm rounded-xl p-4 border border-blue-700 shadow-lg">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-blue-800 flex items-center justify-center flex-shrink-0">
                <Lightbulb className="w-4 h-4 text-yellow-400" />
              </div>
              <div className="flex-1">
                <p className="text-white text-base leading-relaxed">
                  {currentHint.tresc}
                </p>
              </div>
              <div className="flex-shrink-0">
                <span className="text-blue-400 text-xs font-mono">
                  ⏱ 4s
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
