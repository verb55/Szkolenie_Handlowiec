import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '../store/useAppStore';
import { useHintsStore } from '../store/useHintsStore';
import obiekcjeData from '../data/obiekcje.json';
import { X, Zap, ArrowRight, AlertTriangle } from 'lucide-react';

const TIMER_DURATION = 3;

interface ObjectionResponse {
  id: string;
  kontrargument: string;
  pytanie_poglebiajace: string;
  powrot_do_etapu: string;
  power_move: string;
  unikanie_fraz: string[];
}

export function ObjectionPanel() {
  const { isCallActive, goToStage, currentStageId, setObjectionMode } = useAppStore();
  const { hideHint } = useHintsStore();

  const [isOpen, setIsOpen] = useState(false);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [timer, setTimer] = useState(0);
  const [showResponse, setShowResponse] = useState(false);
  const [currentResponse, setCurrentResponse] = useState<ObjectionResponse | null>(null);

  // Get unique tags from all objections
  const allTags = Array.from(
    new Set(obiekcjeData.obiekcje.flatMap((obj) => obj.tagi))
  ).sort();

  // Start timer when tags are selected
  useEffect(() => {
    if (selectedTags.length > 0 && !showResponse) {
      setTimer(TIMER_DURATION);
      const interval = setInterval(() => {
        setTimer((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            findAndShowResponse();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [selectedTags, showResponse]);

  const findAndShowResponse = useCallback(() => {
    // First check for combination matches
    const combination = obiekcjeData.kombinacje.find((combo) =>
      combo.tagi_kombinacja.every((tag) => selectedTags.includes(tag))
    );

    if (combination) {
      setCurrentResponse({
        id: combination.tagi_kombinacja.join('_'),
        kontrargument: combination.kontrargument,
        pytanie_poglebiajace: combination.pytanie_poglebiajace,
        powrot_do_etapu: combination.powrot_do_etapu,
        power_move: combination.power_move,
        unikanie_fraz: [],
      });
      setShowResponse(true);
      return;
    }

    // Then check for single tag matches
    for (const tag of selectedTags) {
      const objection = obiekcjeData.obiekcje.find((obj) =>
        obj.tagi.includes(tag)
      );

      if (objection) {
        setCurrentResponse({
          id: objection.id,
          kontrargument: objection.kontrargument,
          pytanie_poglebiajace: objection.pytanie_poglebiajace,
          powrot_do_etapu: objection.powrot_do_etapu,
          power_move: objection.power_move,
          unikanie_fraz: objection.unikanie_fraz,
        });
        setShowResponse(true);
        return;
      }
    }
  }, [selectedTags]);

  const handleTagToggle = (tag: string) => {
    hideHint(); // Hide any visible hint
    setShowResponse(false);
    setCurrentResponse(null);

    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag));
    } else if (selectedTags.length < 3) {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const handleReturnToStage = () => {
    if (currentResponse) {
      const stageMap: Record<string, number> = {
        Hak: 1,
        Akceptacja: 2,
        Diagnoza: 3,
        Rozwiązanie: 4,
        Autorytet: 5,
        Zamknięcie: 6,
      };

      const stageId = stageMap[currentResponse.powrot_do_etapu] || 3;
      goToStage(stageId);
    }
    handleClose();
  };

  const handleClose = () => {
    setIsOpen(false);
    setSelectedTags([]);
    setShowResponse(false);
    setCurrentResponse(null);
    setTimer(0);
    setObjectionMode(false);
  };

  if (!isCallActive) {
    return null;
  }

  return (
    <>
      {/* FAB Button */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-yellow-500 rounded-full flex items-center justify-center shadow-lg"
        style={{ touchAction: 'manipulation' }}
      >
        <Zap className="w-7 h-7 text-black" />
      </motion.button>

      {/* Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-neutral-950/95 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-neutral-800">
              <h2 className="text-xl font-bold text-white">Obsługa obiekcji</h2>
              <button
                onClick={handleClose}
                className="w-10 h-10 rounded-full bg-neutral-800 flex items-center justify-center"
              >
                <X className="w-5 h-5 text-neutral-400" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-auto p-4">
              {!showResponse ? (
                <>
                  {/* Tag selection */}
                  <p className="text-neutral-400 mb-4">
                    Wybierz 1-3 słowa kluczowe ({selectedTags.length}/3)
                  </p>

                  <div className="flex flex-wrap gap-2 mb-6">
                    {allTags.map((tag) => (
                      <motion.button
                        key={tag}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleTagToggle(tag)}
                        disabled={!selectedTags.includes(tag) && selectedTags.length >= 3}
                        className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                          selectedTags.includes(tag)
                            ? 'bg-yellow-500 text-black'
                            : 'bg-neutral-800 text-neutral-300 hover:bg-neutral-700'
                        } disabled:opacity-50 disabled:cursor-not-allowed`}
                      >
                        {tag}
                      </motion.button>
                    ))}
                  </div>

                  {/* Selected tags indicator */}
                  {selectedTags.length > 0 && (
                    <div className="text-center">
                      <div className="inline-flex items-center gap-2 px-4 py-2 bg-neutral-900 rounded-full">
                        <span className="text-neutral-400 text-sm">Przygotowuję odpowiedź...</span>
                        <span className="w-8 h-8 rounded-full bg-yellow-500 text-black font-bold flex items-center justify-center">
                          {timer}
                        </span>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <>
                  {/* Response card */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    {/* Contrargument */}
                    <div className="bg-neutral-900 rounded-xl p-6">
                      <p className="text-neutral-400 text-sm mb-2">POWIEDZ:</p>
                      <p className="text-white text-lg leading-relaxed">
                        {currentResponse?.kontrargument}
                      </p>
                    </div>

                    {/* Probing question */}
                    <div className="bg-neutral-900 rounded-xl p-6 border-l-4 border-yellow-500">
                      <p className="text-yellow-400 text-sm mb-2">ZAPYTAJ:</p>
                      <p className="text-white text-xl font-bold leading-relaxed">
                        {currentResponse?.pytanie_poglebiajace}
                      </p>
                    </div>

                    {/* Power move */}
                    {currentResponse?.power_move && (
                      <div className="bg-blue-900/30 rounded-xl p-4">
                        <p className="text-blue-400 text-sm mb-1">POWER MOVE:</p>
                        <p className="text-blue-300 text-sm">
                          {currentResponse.power_move}
                        </p>
                      </div>
                    )}

                    {/* Phrases to avoid */}
                    {currentResponse?.unikanie_fraz && currentResponse.unikanie_fraz.length > 0 && (
                      <div className="bg-red-900/30 rounded-xl p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <AlertTriangle className="w-4 h-4 text-red-400" />
                          <p className="text-red-400 text-sm font-medium">UNIKAJ:</p>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {currentResponse.unikanie_fraz.map((phrase, idx) => (
                            <span
                              key={idx}
                              className="px-3 py-1 bg-red-900/50 rounded-full text-red-300 text-xs"
                            >
                              "{phrase}"
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Return button */}
                    <motion.button
                      whileTap={{ scale: 0.98 }}
                      onClick={handleReturnToStage}
                      className="w-full py-4 bg-green-600 hover:bg-green-500 rounded-xl flex items-center justify-center gap-3 text-white font-medium"
                    >
                      <span>Wróć do: {currentResponse?.powrot_do_etapu}</span>
                      <ArrowRight className="w-5 h-5" />
                    </motion.button>
                  </motion.div>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
