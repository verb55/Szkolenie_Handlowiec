import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '../store/useAppStore';
import { Zap, Phone, Calendar, X } from 'lucide-react';

const STREAK_THRESHOLD = 5;
const MODAL_DISPLAY_MS = 3000;
const MILESTONE_INTERVAL = 25;

export function RejectionRecovery() {
  const {
    isCallActive,
    totalCalls,
    totalDemos,
    totalCallbacks,
    totalRejections,
    currentStreak,
    maxStreak,
    recordDemo,
    recordCallback,
    recordRejection,
    resetSession,
  } = useAppStore();

  const [showStreakModal, setShowStreakModal] = useState(false);
  const [showMilestone, setShowMilestone] = useState(false);
  const [selectedOutcome, setSelectedOutcome] = useState<'demo' | 'callback' | 'rejection' | null>(null);
  const [isOutcomeModalOpen, setIsOutcomeModalOpen] = useState(false);
  const [callEnded, setCallEnded] = useState(false);

  // Track when call ends - only show modal after an actual call
  useEffect(() => {
    if (isCallActive) {
      setCallEnded(false);
    } else if (callEnded) {
      // Already tracked a call ending, modal logic below will handle it
    } else {
      // This is first load or call was already tracked
      setCallEnded(true);
    }
  }, [isCallActive]);

  // Trigger streak modal after reaching threshold
  useEffect(() => {
    if (currentStreak >= STREAK_THRESHOLD && !showStreakModal) {
      setShowStreakModal(true);
      const timer = setTimeout(() => {
        setShowStreakModal(false);
      }, MODAL_DISPLAY_MS);
      return () => clearTimeout(timer);
    }
  }, [currentStreak, showStreakModal]);

  // Trigger milestone notification
  useEffect(() => {
    if (totalCalls > 0 && totalCalls % MILESTONE_INTERVAL === 0 && totalCalls >= MILESTONE_INTERVAL) {
      setShowMilestone(true);
      const timer = setTimeout(() => {
        setShowMilestone(false);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [totalCalls]);

  // Open outcome modal when call ends (only after active call)
  useEffect(() => {
    if (!isCallActive && callEnded && selectedOutcome === null && !isOutcomeModalOpen) {
      // Call just ended, wait a moment then show modal
      const timer = setTimeout(() => {
        setIsOutcomeModalOpen(true);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isCallActive, callEnded, selectedOutcome, isOutcomeModalOpen]);

  const handleOutcomeSelect = (outcome: 'demo' | 'callback' | 'rejection') => {
    setSelectedOutcome(outcome);

    switch (outcome) {
      case 'demo':
        recordDemo();
        break;
      case 'callback':
        recordCallback();
        break;
      case 'rejection':
        recordRejection();
        break;
    }

    setIsOutcomeModalOpen(false);
  };

  // Calculate progress to goal (assuming 1 demo per 8 calls)
  const progressPercent = Math.min((totalCalls % 100) + (currentStreak / STREAK_THRESHOLD) * 10, 100);

  // Mock team data (in real app would come from backend)
  const teamMembersWithRejection = Math.floor(Math.random() * 5) + 1;

  return (
    <>
      {/* Streak Modal - appears after 5 consecutive rejections */}
      <AnimatePresence>
        {showStreakModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-neutral-950/90 p-6"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-neutral-900 rounded-2xl p-8 max-w-sm w-full text-center border border-neutral-800"
            >
              <div className="text-4xl mb-4">🔥</div>
              <h2 className="text-2xl font-bold text-white mb-2">
                Streak: {currentStreak} połączeń
              </h2>

              {/* Progress bar */}
              <div className="w-full h-2 bg-neutral-800 rounded-full mb-4 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercent}%` }}
                  className="h-full bg-gradient-to-r from-orange-500 to-yellow-500"
                />
              </div>
              <p className="text-neutral-400 text-sm mb-4">
                {Math.round(progressPercent)}% do celu
              </p>

              {/* Social proof */}
              <div className="flex items-center justify-center gap-2 text-neutral-300 mb-4">
                <span>●</span>
                <span>{teamMembersWithRejection} handlowców z teamu</span>
              </div>
              <p className="text-neutral-500 text-sm mb-6">
                właśnie też usłyszało "nie"
              </p>

              {/* Statistics */}
              <div className="text-neutral-400 text-sm">
                <p>Średnia branżowa: 1 na 8</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Milestone notification */}
      <AnimatePresence>
        {showMilestone && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-20 left-4 right-4 z-50 bg-neutral-900 rounded-xl p-4 border border-neutral-800 shadow-xl"
          >
            <div className="flex items-center gap-3">
              <div className="text-2xl">🏆</div>
              <div>
                <p className="text-white font-medium">
                  {totalCalls} rozmów ukończonych
                </p>
                <p className="text-neutral-400 text-sm">
                  Świetna systematyczność!
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Outcome selection modal */}
      <AnimatePresence>
        {isOutcomeModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end justify-center bg-neutral-950/90"
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="bg-neutral-900 rounded-t-3xl w-full max-w-md p-6"
            >
              <h3 className="text-xl font-bold text-white text-center mb-6">
                Wynik rozmowy
              </h3>

              <div className="flex flex-col gap-3">
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleOutcomeSelect('demo')}
                  className="w-full py-4 px-6 bg-green-600 hover:bg-green-500 rounded-xl flex items-center justify-center gap-3 text-white font-medium"
                >
                  <Calendar className="w-6 h-6" />
                  <span>Umówione Demo</span>
                </motion.button>

                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleOutcomeSelect('callback')}
                  className="w-full py-4 px-6 bg-blue-600 hover:bg-blue-500 rounded-xl flex items-center justify-center gap-3 text-white font-medium"
                >
                  <Phone className="w-6 h-6" />
                  <span>Callback</span>
                </motion.button>

                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleOutcomeSelect('rejection')}
                  className="w-full py-4 px-6 bg-neutral-700 hover:bg-neutral-600 rounded-xl flex items-center justify-center gap-3 text-white font-medium"
                >
                  <X className="w-6 h-6" />
                  <span>Odmowa</span>
                </motion.button>
              </div>

              {/* Current stats - subtle display */}
              <div className="mt-6 flex justify-center gap-6 text-neutral-500 text-sm">
                <div>
                  <span className="text-green-400">{totalDemos}</span> demo
                </div>
                <div>
                  <span className="text-blue-400">{totalCallbacks}</span> callback
                </div>
                <div>
                  <span className="text-neutral-400">{totalRejections}</span> odmów
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
