import { useRef, useCallback, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore, getUserExperienceDays } from '../store/useAppStore';
import { HADAS_STAGES, getStageById } from '../data/stages';
import { useHintsStore } from '../store/useHintsStore';

const SWIPE_THRESHOLD = 80;
const DEBOUNCE_MS = 300;
const LONG_PRESS_MS = 800;

export function StageNavigator() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [touchStart, setTouchStart] = useState<{ x: number; y: number; time: number } | null>(null);
  const [touchEnd, setTouchEnd] = useState<{ x: number; y: number; time: number } | null>(null);
  const [isLongPressing, setIsLongPressing] = useState(false);
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);

  const {
    isCallActive,
    currentStageId,
    isLostMode,
    goToNextStage,
    goToPrevStage,
    goToStage,
    setLostMode,
    setHintMode,
  } = useAppStore();

  const { getHintForStage, showHint } = useHintsStore();

  const currentStage = getStageById(currentStageId);
  const userDays = getUserExperienceDays();

  // Cleanup long press timer
  useEffect(() => {
    return () => {
      if (longPressTimer.current) {
        clearTimeout(longPressTimer.current);
      }
    };
  }, []);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    const touch = e.touches[0];
    setTouchStart({
      x: touch.clientX,
      y: touch.clientY,
      time: Date.now(),
    });
    setTouchEnd(null);

    // Start long press timer
    longPressTimer.current = setTimeout(() => {
      setIsLongPressing(true);
      setLostMode(true);
    }, LONG_PRESS_MS);
  }, [setLostMode]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    const touch = e.touches[0];
    setTouchEnd({
      x: touch.clientX,
      y: touch.clientY,
      time: Date.now(),
    });

    // Cancel long press if moved significantly
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
    setIsLongPressing(false);
  }, []);

  const handleTouchEnd = useCallback(() => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }

    setIsLongPressing(false);

    if (!touchStart || !touchEnd) return;

    const deltaX = touchEnd.x - touchStart.x;
    const deltaY = touchEnd.y - touchStart.y;
    const deltaTime = touchEnd.time - touchStart.time;

    // Check if it was a tap (short touch, minimal movement)
    const isTap = deltaTime < 300 && Math.abs(deltaX) < 10 && Math.abs(deltaY) < 10;

    // Check if it was a long press release (touch duration > threshold)
    const isLongPressRelease = deltaTime > LONG_PRESS_MS;

    if (isLongPressRelease) {
      // Long press released - keep lost mode on
      return;
    }

    if (isTap) {
      // Show hint for current stage
      const hint = getHintForStage(currentStage?.nazwa || 'Hak', userDays);
      if (hint) {
        showHint(hint.id);
      }
      return;
    }

    // Determine swipe direction (use larger delta)
    const isHorizontalSwipe = Math.abs(deltaX) > Math.abs(deltaY);
    const isVerticalSwipe = Math.abs(deltaY) > Math.abs(deltaX);

    if (isHorizontalSwipe && Math.abs(deltaX) > SWIPE_THRESHOLD) {
      // Horizontal swipe
      if (deltaX < 0) {
        // Swipe LEFT - next stage
        goToNextStage();
      } else {
        // Swipe RIGHT - previous stage
        goToPrevStage();
      }
    } else if (isVerticalSwipe && Math.abs(deltaY) > SWIPE_THRESHOLD) {
      // Vertical swipe
      if (deltaY < 0) {
        // Swipe UP - next stage
        goToNextStage();
      } else {
        // Swipe DOWN - previous stage
        goToPrevStage();
      }
    }

    setTouchStart(null);
    setTouchEnd(null);
  }, [touchStart, touchEnd, currentStage, userDays, goToNextStage, goToPrevStage, getHintForStage, showHint]);

  if (!isCallActive || !currentStage) {
    return null;
  }

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 bg-neutral-950 touch-none select-none overflow-hidden"
      style={{ touchAction: 'none' }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Progress bar - passive indicator */}
      <div className="absolute top-0 left-0 right-0 h-2 flex gap-1 p-1">
        {HADAS_STAGES.map((stage) => (
          <div
            key={stage.id}
            className={`flex-1 rounded-full transition-all duration-300 ${
              stage.id <= currentStageId
                ? 'bg-white'
                : 'bg-neutral-700'
            }`}
          />
        ))}
      </div>

      {/* Stage indicator - top */}
      <div className="absolute top-6 left-0 right-0 flex justify-center">
        <div
          className="px-4 py-2 rounded-full text-sm font-medium"
          style={{ backgroundColor: `${currentStage.kolor}20`, color: currentStage.kolor }}
        >
          {currentStage.skrot}
        </div>
      </div>

      {/* Main content - center */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStageId}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
          className="absolute inset-0 flex flex-col items-center justify-center px-8"
        >
          <h1 className="text-4xl font-bold text-white mb-4 text-center">
            {currentStage.nazwa}
          </h1>
          <p className="text-neutral-400 text-center text-lg max-w-md">
            {currentStage.opis}
          </p>
        </motion.div>
      </AnimatePresence>

      {/* Hint indicator - bottom left */}
      <div className="absolute bottom-4 left-4 right-4 text-center text-neutral-500 text-xs">
        Swipe ← → by nawigować • Strefa górna = mapa skryptu
      </div>

      {/* Lost mode overlay */}
      <AnimatePresence>
        {isLostMode && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-neutral-950/95 flex flex-col items-center justify-center p-8"
          >
            <h2 className="text-2xl font-bold text-white mb-8">Wybierz etap</h2>
            <div className="flex flex-col gap-3 w-full max-w-xs">
              {HADAS_STAGES.map((stage) => (
                <motion.button
                  key={stage.id}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => goToStage(stage.id)}
                  className={`w-full py-4 px-6 rounded-xl text-lg font-medium transition-all ${
                    stage.id === currentStageId
                      ? 'ring-2 ring-white'
                      : ''
                  }`}
                  style={{
                    backgroundColor: `${stage.kolor}30`,
                    color: stage.kolor,
                  }}
                >
                  <span className="mr-2 opacity-50">{stage.skrot}</span>
                  {stage.nazwa}
                </motion.button>
              ))}
            </div>
            <button
              onClick={() => setLostMode(false)}
              className="mt-8 text-neutral-400 hover:text-white transition-colors"
            >
              Zamknij (tap poza przyciski)
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
