import { motion } from 'framer-motion';
import { useAppStore, getUserExperienceDays } from '../store/useAppStore';
import { Phone, PhoneCall, BarChart3, Zap } from 'lucide-react';

export function StartScreen() {
  const { isCallActive, totalCalls, totalDemos, totalCallbacks, totalRejections, currentStreak, setCallActive, initializeUser } = useAppStore();
  const userDays = getUserExperienceDays();

  const handleStartCall = () => {
    initializeUser();
    setCallActive(true);
  };

  // Calculate conversion rate
  const conversionRate = totalCalls > 0 ? Math.round((totalDemos / totalCalls) * 100) : 0;

  return (
    <div className="min-h-screen bg-neutral-950 flex flex-col">
      {/* Header */}
      <div className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Sales Assistant</h1>
            <p className="text-neutral-500 text-sm">
              {userDays > 0 ? `Dzień ${userDays} z nami` : 'Pierwszy dzień'}
            </p>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-white">{totalCalls}</p>
            <p className="text-neutral-500 text-sm">rozmów</p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="px-6 grid grid-cols-2 gap-4 mb-6">
        <motion.div
          whileTap={{ scale: 0.98 }}
          className="bg-neutral-900 rounded-xl p-4"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-green-600/20 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{conversionRate}%</p>
              <p className="text-neutral-500 text-xs">konwersja</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          whileTap={{ scale: 0.98 }}
          className="bg-neutral-900 rounded-xl p-4"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-orange-600/20 flex items-center justify-center">
              <Zap className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{currentStreak}</p>
              <p className="text-neutral-500 text-xs">streak</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Detailed Stats */}
      <div className="px-6 mb-6">
        <div className="bg-neutral-900 rounded-xl p-4">
          <h3 className="text-neutral-400 text-sm mb-3">Podsumowanie</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-neutral-300">Demo umówione</span>
              </div>
              <span className="text-white font-medium">{totalDemos}</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500" />
                <span className="text-neutral-300">Callback</span>
              </div>
              <span className="text-white font-medium">{totalCallbacks}</span>
            </div>
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-neutral-600" />
                <span className="text-neutral-300">Odmówiono</span>
              </div>
              <span className="text-white font-medium">{totalRejections}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main CTA */}
      <div className="flex-1 flex flex-col justify-end p-6">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={handleStartCall}
          className="w-full py-6 bg-green-600 hover:bg-green-500 rounded-2xl flex items-center justify-center gap-4 text-white"
          style={{ touchAction: 'manipulation' }}
        >
          <PhoneCall className="w-8 h-8" />
          <span className="text-2xl font-bold">Rozpocznij rozmowę</span>
        </motion.button>

        <p className="text-neutral-500 text-sm text-center mt-4">
          Swipe prawo/lewo by nawigować • Strefa górna = mapa skryptu
        </p>
      </div>

      {/* Version info */}
      <div className="p-4 text-center">
        <p className="text-neutral-700 text-xs">Sales Assistant v1.0 MVP</p>
      </div>
    </div>
  );
}
