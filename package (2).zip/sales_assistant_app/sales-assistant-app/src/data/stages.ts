// Metodologia HADAS - Karol Froń
export const HADAS_STAGES = [
  {
    id: 1,
    nazwa: "Hak",
    skrot: "HAK",
    opis: "Zaczepka, która przyciąga uwagę i budzi zainteresowanie",
    kolor: "#F5A623",
    przykladowe_zdanie: "Czy wiesz, że firmy w Twojej branși tracą średnio 15% budżetu na..."
  },
  {
    id: 2,
    nazwa: "Akceptacja",
    skrot: "AKC",
    opis: "Klient akceptuje, że problem istnieje i jest istotny",
    kolor: "#4A90E2",
    przykladowe_zdanie: "Rozumiem, że to może być frustrujące..."
  },
  {
    id: 3,
    nazwa: "Diagnoza",
    skrot: "DGZ",
    opis: "Dogłębne zbadanie problemu i potrzeb klienta",
    kolor: "#9B59B6",
    przykladowe_zdanie: "Powiedz mi więcej — jak to wygląda w praktyce?"
  },
  {
    id: 4,
    nazwa: "Rozwiązanie",
    skrot: "RZW",
    opis: "Prezentacja rozwiązania dopasowanego do potrzeb",
    kolor: "#2ECC71",
    przykladowe_zdanie: "Nasze rozwiązanie zmniejsza ten problem o 40%..."
  },
  {
    id: 5,
    nazwa: "Autorytet",
    skrot: "AUT",
    opis: "Wzmocnienie wiarygodności i przełamanie ostatnich wątpliwości",
    kolor: "#E74C3C",
    przykladowe_zdanie: "Firma X z Twojej branży osiągnęła takie same rezultaty..."
  },
  {
    id: 6,
    nazwa: "Zamknięcie",
    skrot: "ZMK",
    opis: "Finalne domknięcie sprzedaży i ustalenie kolejnych kroków",
    kolor: "#1ABC9C",
    przykladowe_zdanie: "Czy umawiamy demo na środę o 10:00?"
  }
] as const;

export type HadasStage = typeof HADAS_STAGES[number];

export const getStageById = (id: number): HadasStage | undefined => {
  return HADAS_STAGES.find(stage => stage.id === id);
};

export const getStageByName = (name: string): HadasStage | undefined => {
  return HADAS_STAGES.find(stage => stage.nazwa.toLowerCase() === name.toLowerCase());
};

export const getNextStage = (currentId: number): HadasStage | undefined => {
  return getStageById(currentId + 1);
};

export const getPrevStage = (currentId: number): HadasStage | undefined => {
  return getStageById(currentId - 1);
};
