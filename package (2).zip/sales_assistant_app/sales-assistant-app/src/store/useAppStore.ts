import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import localforage from 'localforage';

// Konfiguracja localforage dla lepszej wydajności offline
localforage.config({
  name: 'sales-assistant',
  storeName: 'app_state',
});

const zustandStorage = {
  getItem: async (name: string): Promise<string | null> => {
    const value = await localforage.getItem<string>(name);
    return value ?? null;
  },
  setItem: async (name: string, value: string): Promise<void> => {
    await localforage.setItem(name, value);
  },
  removeItem: async (name: string): Promise<void> => {
    await localforage.removeItem(name);
  },
};

// Typy dla stanu aplikacji
interface AppState {
  // Stan sesji
  isCallActive: boolean;
  currentStageId: number;
  isObjectionMode: boolean;
  isHintMode: boolean;
  isLostMode: boolean;

  // Statystyki
  totalCalls: number;
  totalDemos: number;
  totalCallbacks: number;
  totalRejections: number;
  currentStreak: number;
  maxStreak: number;
  sessionStartDate: string | null;

  // User preferences
  userStartDate: string | null;
  hintsDisabled: boolean;

  // Akcje - nawigacja skryptem
  setCallActive: (active: boolean) => void;
  goToNextStage: () => void;
  goToPrevStage: () => void;
  goToStage: (stageId: number) => void;
  resetToFirstStage: () => void;

  // Akcje - tryby
  setObjectionMode: (mode: boolean) => void;
  setHintMode: (mode: boolean) => void;
  setLostMode: (mode: boolean) => void;

  // Akcje - statystyki
  recordDemo: () => void;
  recordCallback: () => void;
  recordRejection: () => void;
  resetSession: () => void;

  // Akcje - user
  setHintsDisabled: (disabled: boolean) => void;
  initializeUser: () => void;

  // Haptic feedback helper
  triggerHaptic: (type: 'light' | 'medium' | 'heavy') => void;
}

const HADAS_STAGE_COUNT = 6;

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Stan początkowy
      isCallActive: false,
      currentStageId: 1,
      isObjectionMode: false,
      isHintMode: true,
      isLostMode: false,

      totalCalls: 0,
      totalDemos: 0,
      totalCallbacks: 0,
      totalRejections: 0,
      currentStreak: 0,
      maxStreak: 0,
      sessionStartDate: null,

      userStartDate: null,
      hintsDisabled: false,

      // Nawigacja skryptem
      setCallActive: (active) => {
        set({
          isCallActive: active,
          isLostMode: false,
          isObjectionMode: false,
          currentStageId: active ? 1 : get().currentStageId,
          sessionStartDate: active ? new Date().toISOString() : get().sessionStartDate,
        });
      },

      goToNextStage: () => {
        const { currentStageId } = get();
        if (currentStageId < HADAS_STAGE_COUNT) {
          set({ currentStageId: currentStageId + 1 });
          get().triggerHaptic('light');
        }
      },

      goToPrevStage: () => {
        const { currentStageId } = get();
        if (currentStageId > 1) {
          set({ currentStageId: currentStageId - 1 });
          get().triggerHaptic('light');
        }
      },

      goToStage: (stageId) => {
        if (stageId >= 1 && stageId <= HADAS_STAGE_COUNT) {
          set({ currentStageId: stageId, isLostMode: false });
          get().triggerHaptic('medium');
        }
      },

      resetToFirstStage: () => {
        set({ currentStageId: 1 });
        get().triggerHaptic('heavy');
      },

      // Tryby
      setObjectionMode: (mode) => set({ isObjectionMode: mode }),
      setHintMode: (mode) => set({ isHintMode: mode }),
      setLostMode: (mode) => set({ isLostMode: mode }),

      // Statystyki
      recordDemo: () => {
        const state = get();
        set({
          totalDemos: state.totalDemos + 1,
          totalCalls: state.totalCalls + 1,
          currentStreak: state.currentStreak + 1,
          maxStreak: Math.max(state.maxStreak, state.currentStreak + 1),
          isCallActive: false,
        });
        get().triggerHaptic('heavy');
      },

      recordCallback: () => {
        const state = get();
        set({
          totalCallbacks: state.totalCallbacks + 1,
          totalCalls: state.totalCalls + 1,
          currentStreak: state.currentStreak + 1,
          maxStreak: Math.max(state.maxStreak, state.currentStreak + 1),
          isCallActive: false,
        });
        get().triggerHaptic('medium');
      },

      recordRejection: () => {
        const state = get();
        // Streak measures ATTEMPTS, not successes - increment on every call including rejections
        set({
          totalRejections: state.totalRejections + 1,
          totalCalls: state.totalCalls + 1,
          currentStreak: state.currentStreak + 1,
          maxStreak: Math.max(state.maxStreak, state.currentStreak + 1),
          isCallActive: false,
        });
        get().triggerHaptic('heavy');
      },

      resetSession: () => {
        set({
          isCallActive: false,
          currentStageId: 1,
          isLostMode: false,
          isObjectionMode: false,
        });
      },

      // User
      setHintsDisabled: (disabled) => set({ hintsDisabled: disabled }),

      initializeUser: () => {
        const { userStartDate } = get();
        if (!userStartDate) {
          set({ userStartDate: new Date().toISOString() });
        }
      },

      // Haptic feedback
      triggerHaptic: (type) => {
        if (typeof navigator !== 'undefined' && navigator.vibrate) {
          const patterns = {
            light: [50],
            medium: [100],
            heavy: [200, 100, 200],
          };
          navigator.vibrate(patterns[type]);
        }
      },
    }),
    {
      name: 'sales-assistant-storage',
      storage: createJSONStorage(() => zustandStorage),
      partialize: (state) => ({
        totalCalls: state.totalCalls,
        totalDemos: state.totalDemos,
        totalCallbacks: state.totalCallbacks,
        totalRejections: state.totalRejections,
        currentStreak: state.currentStreak,
        maxStreak: state.maxStreak,
        userStartDate: state.userStartDate,
        hintsDisabled: state.hintsDisabled,
      }),
    }
  )
);

// Helper do wyliczania dni doświadczenia
export const getUserExperienceDays = (): number => {
  const state = useAppStore.getState();
  if (!state.userStartDate) return 0;

  const startDate = new Date(state.userStartDate);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - startDate.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};
