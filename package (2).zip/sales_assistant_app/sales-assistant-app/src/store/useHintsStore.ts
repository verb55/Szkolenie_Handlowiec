import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import localforage from 'localforage';
import hintsData from '../data/hints.json';

localforage.config({
  name: 'sales-assistant',
  storeName: 'hints_state',
});

const zustandStorage = {
  getItem: async (name: string): Promise<string | null> => {
    const value = await localforage.getItem<string>(name);
    return value ?? null;
  },
  setItem: async (name: string, value: string): Promise<void> => {
    await localforage.setItem(name, value);
  },
  removeItem: async (name: string): Promise<void> => {
    await localforage.removeItem(name);
  },
};

interface HintInteraction {
  hintId: string;
  seen: boolean;
  interacted: boolean;
  ignored: boolean;
  lastSeen: string | null;
  sessionIgnores: number;
  totalIgnores: number;
}

interface HintsState {
  hintStats: Record<string, HintInteraction>;
  currentHintId: string | null;
  hintVisible: boolean;

  // Akcje
  showHint: (hintId: string) => void;
  hideHint: () => void;
  recordInteraction: (hintId: string, interacted: boolean) => void;
  getHintForStage: (stageName: string, userDays: number) => typeof hintsData.hints[0] | null;
  isHintEnabled: (hintId: string) => boolean;
}

export const useHintsStore = create<HintsState>()(
  persist(
    (set, get) => ({
      hintStats: {},
      currentHintId: null,
      hintVisible: false,

      showHint: (hintId) => {
        const { hintStats, isHintEnabled } = get();

        if (!isHintEnabled(hintId)) return;

        // Initialize stats for this hint if not exists
        if (!hintStats[hintId]) {
          hintStats[hintId] = {
            hintId,
            seen: false,
            interacted: false,
            ignored: false,
            lastSeen: null,
            sessionIgnores: 0,
            totalIgnores: 0,
          };
        }

        set({
          currentHintId: hintId,
          hintVisible: true,
          hintStats: { ...hintStats },
        });
      },

      hideHint: () => {
        const { currentHintId, hintStats } = get();

        if (currentHintId && hintStats[currentHintId]) {
          const stats = hintStats[currentHintId];
          const wasIgnored = !stats.interacted;

          hintStats[currentHintId] = {
            ...stats,
            seen: true,
            lastSeen: new Date().toISOString(),
            ignored: wasIgnored,
            sessionIgnores: wasIgnored ? stats.sessionIgnores + 1 : stats.sessionIgnores,
            totalIgnores: wasIgnored ? stats.totalIgnores + 1 : stats.totalIgnores,
          };

          set({ hintStats: { ...hintStats } });
        }

        set({ hintVisible: false, currentHintId: null });
      },

      recordInteraction: (hintId, interacted) => {
        const { hintStats } = get();

        if (!hintStats[hintId]) {
          hintStats[hintId] = {
            hintId,
            seen: true,
            interacted: true,
            ignored: false,
            lastSeen: new Date().toISOString(),
            sessionIgnores: 0,
            totalIgnores: 0,
          };
        } else {
          hintStats[hintId] = {
            ...hintStats[hintId],
            interacted: interacted || hintStats[hintId].interacted,
            ignored: false,
          };
        }

        set({ hintStats: { ...hintStats } });
      },

      getHintForStage: (stageName, userDays) => {
        const { hintStats, isHintEnabled } = get();

        // Filter hints for this stage and user experience
        const stageHints = hintsData.hints.filter(hint => {
          if (hint.etap !== stageName) return false;

          // Check experience level
          if (hint.dla_strazu === '< 30 dni' && userDays >= 30) return false;
          if (hint.dla_strazu === '> 30 dni' && userDays < 30) return false;

          return true;
        });

        // Shuffle for variety
        const shuffled = [...stageHints].sort(() => Math.random() - 0.5);

        // Find first enabled hint
        for (const hint of shuffled) {
          if (isHintEnabled(hint.id)) {
            return hint;
          }
        }

        return null;
      },

      isHintEnabled: (hintId) => {
        const { hintStats } = get();
        const stats = hintStats[hintId];

        if (!stats) return true; // Never seen, show it

        // Permanent delete after 5 ignores across 3 sessions (simplified: 5 total)
        if (stats.totalIgnores >= 5) return false;

        // Pause after 3 ignores in current session
        if (stats.sessionIgnores >= 3) {
          if (stats.lastSeen) {
            const lastSeenDate = new Date(stats.lastSeen);
            const now = new Date();
            const daysSince = Math.floor((now.getTime() - lastSeenDate.getTime()) / (1000 * 60 * 60 * 24));
            return daysSince >= 7; // Re-appear after 7 days
          }
        }

        return true;
      },
    }),
    {
      name: 'hints-storage',
      storage: createJSONStorage(() => zustandStorage),
    }
  )
);

// Reset session ignores (call at start of new session)
export const resetSessionIgnores = () => {
  const { hintStats } = useHintsStore.getState();

  const updatedStats = { ...hintStats };
  Object.keys(updatedStats).forEach(key => {
    updatedStats[key] = {
      ...updatedStats[key],
      sessionIgnores: 0,
    };
  });

  useHintsStore.setState({ hintStats: updatedStats });
};
