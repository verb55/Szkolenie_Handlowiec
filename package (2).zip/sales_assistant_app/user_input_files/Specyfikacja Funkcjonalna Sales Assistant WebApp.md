# Specyfikacja Funkcjonalna Sales Assistant WebApp

Niniejszy dokument przedstawia specyfikację funkcjonalną dla Sales Assistant WebApp, narzędzia wspierającego handlowców terenowych w Polsce w procesie cold callingu. Projekt uwzględnia perspektywy psychologiczne, doświadczenia użytkownika (UX) oraz strategie sprzedażowe, bazując na metodologii Karola Fronia.

## MODUŁ 1 — NAWIGACJA SKRYPTEM JEDNYM KCIUKIEM

### (a) Co robi
Moduł ten umożliwia handlowcowi płynne przechodzenie przez kolejne etapy skryptu rozmowy telefonicznej, wykorzystując intuicyjne gesty i strefy dotykowe. Zapewnia to obsługę aplikacji bez konieczności patrzenia na ekran, co jest kluczowe podczas prowadzenia rozmowy.

### (b) Jak wygląda
Ekran rozmowy jest podzielony na trzy główne strefy dotykowe: lewą, prawą i dolną. Przesunięcie kciukiem w prawo (swipe right) na środkowej części ekranu przenosi handlowca do następnego kroku skryptu. Przesunięcie w lewo (swipe left) cofa do poprzedniego kroku. Dotknięcie dolnej części ekranu (tap bottom) aktywuje tryb "zgubiłem się", wyświetlając uproszczony widok wszystkich kroków skryptu z możliwością szybkiego wyboru odpowiedniego etapu. Tekst aktualnego kroku skryptu jest wyświetlany dużą czcionką na środku ekranu.

### (c) Dlaczego to działa
**[UX]** Projekt wykorzystuje zasadę **Single-Thumb Navigation**, optymalizując interakcję dla użytkownika trzymającego telefon w jednej ręce. Gesty swipe są naturalne i szybkie, minimalizując obciążenie poznawcze i motoryczne. Aktywacja trybu "zgubiłem się" poprzez tapnięcie w dolną strefę ekranu (łatwo dostępną dla kciuka) zapewnia szybkie wyjście z trudnej sytuacji, redukując stres i zwiększając poczucie kontroli handlowca. Uproszczony widok kroków skryptu wykorzystuje **efekt Von Restorffa**, gdzie unikalne elementy (aktualny krok) są łatwiej zapamiętywane i identyfikowane, co ułatwia szybkie odnalezienie się w rozmowie.

### (d) Ryzyko
Główne ryzyko implementacyjne to zapewnienie precyzyjnego rozpoznawania gestów w różnych warunkach (np. ruch, potliwość dłoni) oraz uniknięcie przypadkowych aktywacji, które mogłyby zakłócić rozmowę.

## MODUŁ 2 — REJECTION RECOVERY SYSTEM

### (a) Co robi
Moduł ten ma za zadanie podtrzymywać motywację handlowca po serii odrzuceń, normalizując niepowodzenia jako naturalną część procesu sprzedaży. System nagradza wysiłek, a nie tylko wynik, przeciwdziałając wypaleniu.

### (b) Jak wygląda
Po pięciu kolejnych odrzuceniach (np. klient rozłączył się, odmówił rozmowy), na ekranie pojawia się subtelna, animowana ikona (np. mała, stylizowana tarcza z symbolem "+1 do odporności") w górnym rogu ekranu, która znika po 2 sekundach. Jednocześnie, w tle, odtwarzany jest krótki, motywujący dźwięk (np. delikatny gong lub krótka, pozytywna melodia). W sekcji statystyk handlowca, licznik "Odrzuceń" zwiększa się, a obok niego pojawia się ikona "Odporność" z rosnącym poziomem. Po osiągnięciu określonego progu odporności (np. 20 odrzuceń), handlowiec otrzymuje wirtualną "odznakę" (np. "Niezłomny Wojownik") widoczną w jego profilu.

### (c) Dlaczego to działa
**[PSYCHOLOG]** Mechanizm ten wykorzystuje **grywalizację** i **warunkowanie instrumentalne**. Subtelna animacja i dźwięk stanowią natychmiastową, pozytywną informację zwrotną za podjęcie próby (nagroda za proces, nie za wynik), co aktywuje układ nagrody w mózgu (dopamina), przeciwdziałając spadkowi motywacji po odrzuceniu [1]. Normalizacja odrzucenia następuje poprzez jego kategoryzację jako "Odporność", co zmienia perspektywę z porażki na budowanie umiejętności. Wirtualne odznaki wykorzystują **efekt Zeigarnik** (dążenie do ukończenia zadań) oraz **społeczne dowody słuszności** (chęć bycia częścią grupy osiągającej sukcesy), motywując do dalszego działania i budowania poczucia osiągnięcia.

### (d) Ryzyko
Ryzykiem jest niewłaściwe skalibrowanie częstotliwości i intensywności nagród, co może prowadzić do ich zbagatelizowania lub, przeciwnie, do irytacji użytkownika, jeśli będą zbyt nachalne. Kluczowe jest utrzymanie subtelności i pozytywnego skojarzenia.

## MODUŁ 3 — DRZEWO OBIEKCJI OPARTE NA SŁOWACH KLUCZOWYCH

### (a) Co robi
Moduł ten pomaga handlowcowi szybko reagować na obiekcje klienta, dostarczając gotowe kontrargumenty, pytania pogłębiające i sugestie powrotu do odpowiedniego etapu skryptu. System działa na zasadzie tagowania słów kluczowych, eliminując potrzebę przeszukiwania długich list.

### (b) Jak wygląda
Po usłyszeniu obiekcji, handlowiec dotyka ikony "Obiekcje" (np. dymek dialogowy) w prawym dolnym rogu ekranu. Pojawia się pole tekstowe z predykcyjnym wyszukiwaniem oraz lista najczęściej używanych tagów (np. "drogo", "nie teraz", "mamy dostawcę"). Handlowiec może wpisać 1-3 słowa kluczowe lub wybrać je z listy. Po wybraniu, na ekranie natychmiast pojawia się karta z trzema sekcjami: "Kontrargument" (np. "Rozumiem, że cena jest ważna, i właśnie dlatego chcę pokazać..."), "Pytanie Pogłębiające" (np. "Co konkretnie sprawia, że uważa Pan, że jest za drogo?") oraz "Powrót do Skryptu" (np. "KROK III: Diagnoza Problemów"). Karta znika po dotknięciu poza jej obszarem lub po 10 sekundach.

### (c) Dlaczego to działa
**[SPRZEDAŻ]** System ten skraca czas reakcji handlowca na obiekcje, co jest kluczowe dla utrzymania dynamiki rozmowy i profesjonalizmu. Wykorzystanie słów kluczowych i predykcyjnego wyszukiwania minimalizuje wysiłek poznawczy handlowca w stresującej sytuacji, pozwalając mu skupić się na kliencie. Dostarczanie gotowych, sprawdzonych kontrargumentów i pytań pogłębiających zwiększa **skuteczność skryptu** i **konwersję**, ponieważ handlowiec zawsze ma pod ręką najlepszą odpowiedź. Sugestia powrotu do etapu skryptu (np. Diagnoza) pomaga w **obsłudze obiekcji** poprzez ponowne ukierunkowanie rozmowy na potrzeby klienta, zgodnie z metodologią Karola Fronia.

### (d) Ryzyko
Ryzykiem jest niedokładność algorytmu tagowania słów kluczowych, co może prowadzić do wyświetlania nieadekwatnych odpowiedzi. Wymaga to starannego zaprojektowania bazy obiekcji i ich tagów, a także mechanizmu uczenia się na podstawie feedbacku handlowców.

### Przykładowy JSON struktury jednej obiekcji:

```json
{
  "id": "obj_001",
  "tags": ["drogo", "cena", "koszt"],
  "kontrargument": "Rozumiem, że cena jest ważnym czynnikiem. I właśnie dlatego chcę pokazać, jak ta cena przekłada się na wartość i zwrot z inwestycji w perspektywie długoterminowej.",
  "pytanie_poglebiajace": "Co konkretnie sprawia, że uważa Pan, że nasza oferta jest za droga w porównaniu do czego?",
  "sugestia_powrotu_do_skryptu": "KROK III: Diagnoza Problemów",
  "metodologia_fronia_odniesienie": "Komunikacyjne Aikido, Moduł 5"
}
```

## MODUŁ 4 — JUST-IN-TIME MICRO-LEARNING

### (a) Co robi
Moduł ten dostarcza kontekstowe wskazówki i mikro-szkolenia w czasie rzeczywistym, dostosowane do poziomu doświadczenia handlowca. Ma na celu przyspieszenie adaptacji nowych handlowców i ciągłe doskonalenie umiejętności weteranów.

### (b) Jak wygląda
Podczas rozmowy, w kluczowych momentach (np. po zakończeniu KROKU I przez nowego handlowca, lub gdy weteran spędza zbyt dużo czasu w KROKU III), w górnej części ekranu pojawia się mały, półprzezroczysty "hint" (np. "Pamiętaj o pauzie po Haku!"). Hint jest wyświetlany przez 4 sekundy, a następnie automatycznie znika. Nowi handlowcy (< 30 dni stażu) widzą szerszy zakres hintów, skupiających się na podstawach metodologii. Weterani widzą hinty dotyczące bardziej zaawansowanych technik lub przypomnienia o kluczowych elementach. System monitoruje, czy handlowiec wykonuje akcję sugerowaną przez hint; jeśli hint jest konsekwentnie ignorowany (np. brak pauzy po haku mimo wyświetlania hintu), system przestaje go wyświetlać dla tego handlowca.

### (c) Dlaczego to działa
**[PSYCHOLOG][UX]** Mechanizm **Just-in-Time Micro-Learning** wykorzystuje zasadę **uczenia się kontekstowego** i **efektu świeżości** (recency effect), dostarczając informacje dokładnie wtedy, gdy są potrzebne i najbardziej relewantne, co zwiększa ich przyswajalność i retencję [2]. Krótki czas wyświetlania (4 sekundy) zapobiega przeciążeniu informacjami i nie odwraca uwagi od rozmowy, jednocześnie wykorzystując **pamięć krótkotrwałą**. Adaptacyjne wyświetlanie hintów (uczenie się, które hinty są ignorowane) zapobiega **habituacji** i irytacji, utrzymując system jako wartościowe wsparcie, a nie przeszkodę. Różnicowanie hintów dla nowych i doświadczonych handlowców wspiera **indywidualizację nauczania**, co jest zgodne z zasadami efektywnej pedagogiki.

### (d) Ryzyko
Ryzykiem jest błędne zidentyfikowanie "kluczowych momentów" lub nieprawidłowe algorytmy oceny ignorowania hintów, co może prowadzić do wyświetlania nieistotnych lub irytujących podpowiedzi. Wymaga to ciągłego monitorowania i kalibracji systemu na podstawie danych z użytkowania.

## User Flow: Handlowiec dzwoni, klient mówi że jest za drogo, handlowiec obsługuje obiekcję i umawia demo.

**Krok 1: Rozpoczęcie rozmowy**
*   **Akcja użytkownika:** Handlowiec inicjuje połączenie z klientem. Aplikacja wyświetla pierwszy krok skryptu (KROK I: Hak).
*   **Reakcja systemu:** Aplikacja wyświetla tekst KROKU I. Dla nowego handlowca pojawia się hint: "Pamiętaj o pauzie po Haku!" (znika po 4s).
*   **Następny krok:** Handlowiec wypowiada Hak.

**Krok 2: Przejście do KROKU II**
*   **Akcja użytkownika:** Handlowiec wykonuje gest swipe right na ekranie.
*   **Reakcja systemu:** Aplikacja wyświetla tekst KROKU II (Akceptacja na rozmowę).
*   **Następny krok:** Handlowiec wypowiada formułę akceptacji.

**Krok 3: Przejście do KROKU III**
*   **Akcja użytkownika:** Handlowiec wykonuje gest swipe right na ekranie.
*   **Reakcja systemu:** Aplikacja wyświetla tekst KROKU III (Diagnoza Problemów).
*   **Następny krok:** Handlowiec zadaje pytanie diagnostyczne.

**Krok 4: Klient zgłasza obiekcję "za drogo"**
*   **Akcja użytkownika:** Klient mówi: "To brzmi ciekawie, ale pewnie jest za drogo."
*   **Reakcja systemu:** (Brak bezpośredniej reakcji, handlowiec musi zainicjować obsługę obiekcji).
*   **Następny krok:** Handlowiec aktywuje moduł obiekcji.

**Krok 5: Obsługa obiekcji**
*   **Akcja użytkownika:** Handlowiec dotyka ikony "Obiekcje" w prawym dolnym rogu ekranu. Wpisuje "drogo" lub wybiera tag "drogo" z listy.
*   **Reakcja systemu:** Aplikacja natychmiast wyświetla kartę z: Kontrargumentem ("Rozumiem, że cena jest ważna..."), Pytaniem Pogłębiającym ("Co konkretnie sprawia...") oraz Sugestią Powrotu do Skryptu ("KROK III: Diagnoza Problemów"). Karta znika po 10s.
*   **Następny krok:** Handlowiec wykorzystuje podpowiedzi do obsługi obiekcji.

**Krok 6: Powrót do KROKU III i kontynuacja diagnozy**
*   **Akcja użytkownika:** Handlowiec, po obsłużeniu obiekcji, kontynuuje rozmowę, zadając pytanie pogłębiające i wracając do diagnozy problemów klienta.
*   **Reakcja systemu:** Aplikacja nadal wyświetla KROK III.
*   **Następny krok:** Handlowiec przechodzi do KROKU IV.

**Krok 7: Przejście do KROKU IV**
*   **Akcja użytkownika:** Handlowiec wykonuje gest swipe right na ekranie.
*   **Reakcja systemu:** Aplikacja wyświetla tekst KROKU IV (Rozwiązanie).
*   **Następny krok:** Handlowiec przedstawia rozwiązanie.

**Krok 8: Przejście do KROKU V**
*   **Akcja użytkownika:** Handlowiec wykonuje gest swipe right na ekranie.
*   **Reakcja systemu:** Aplikacja wyświetla tekst KROKU V (Autorytet).
*   **Następny krok:** Handlowiec buduje swój autorytet.

**Krok 9: Przejście do KROKU VI i umówienie demo**
*   **Akcja użytkownika:** Handlowiec wykonuje gest swipe right na ekranie. Zadaje pytanie o umówienie spotkania: "Czy umówimy się na spotkanie? Myślę, że 20-30 minut wystarczy. Kiedy by Panu najbardziej odpowiadało?"
*   **Reakcja systemu:** Aplikacja wyświetla tekst KROKU VI (Zamknięcie). Klient akceptuje propozycję demo.
*   **Następny krok:** Handlowiec kończy rozmowę i rejestruje wynik.

## References

[1] Schultz, W. (2017). Reward prediction error. *Scholarpedia*, 12(11), 21722.
[2] Baddeley, A. D. (1992). Working memory. *Science*, 255(5044), 556-559.
